See http://commons.apache.org/pool/ for additional and 
up-to-date information on Apache Commons Pool.
